# Varejão da Limpeza — site estático para GitHub Pages

Site em HTML, CSS e JavaScript puro, sem backend ou dependências pagas.

## Publicar no GitHub Pages
1. Crie um repositório no GitHub (ou abra o repositório que deseja usar).
2. Envie `index.html`, `style.css`, `script.js` e a pasta `assets/` para a raiz do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/ (root)` e salve.
6. Aguarde a publicação e abra o endereço informado pelo GitHub Pages.

## Atualizar catálogo
O catálogo Vonixx está no `index.html`. Cada produto tem nome, categoria, descrição e link para consulta. Para adicionar um produto, duplique um bloco `<article class="product-card">` e atualize `data-name`, `data-category`, nome, descrição e link de consulta.

## Observações importantes
- O catálogo incluído é uma seleção inicial; ele não garante que todos os SKUs da Vonixx estejam cadastrados. O botão “Ver catálogo oficial completo” direciona ao catálogo oficial da marca.
- Confirmar com a loja preços, disponibilidade, nomes, versões e aplicações antes de divulgar.
- A imagem de higienização deve ser substituída por uma foto real do equipamento/serviço, se a atual não representar fielmente o serviço oferecido.
- Endereço e WhatsApp cadastrados conforme as informações fornecidas: Rua Professor Pinto de Aguiar, 22 — Boca do Rio, Salvador - BA; (71) 99161-8530.
